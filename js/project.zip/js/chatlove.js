var chatBtn = document.getElementById("chat-btn");
var loveBtn = document.getElementById("love-btn");
var navBtn = document.querySelector(".btn-nav");

var loveWrap = document.querySelector(".love-wrap");
var chatWrap = document.querySelector(".chatting-wrap");
var chatContent = document.querySelector(".chatting-content");

var chatTop = document.querySelector(".chatting-top");
var chatBot = document.querySelector(".chatting-bot");

var zIdxBtn = 100;
loveBtn.onclick = () => {

    if (loveWrap.style.display == "block") {
        loveWrap.style.display = "none"
        loveBtn.style.backgroundColor = "";
        loveWrap.innerHTML="";

    } else {
        loveWrap.style.display = "block"
        loveBtn.style.backgroundColor = "blue";
        loveWrap.style.zIndex = ++zIdxBtn;

        //찜목록 상단 생성
        var loveTop = document.createElement("div");
        loveTop.classList.add("love-top");
        loveTop.innerHTML = '<h3>찜한 상품 목록</h1>';

        var loveContent = document.createElement("div");
        loveContent.classList.add("love-content");


        var ul = document.createElement("ul");

        for(var i = 0; i < 3; i++){
            var li = document.createElement("li");
            li.classList.add("love-item");
            li.innerHTML = `<img src="./img/profile.png" alt="찜이미지">`;

            var div = document.createElement("div");
            div.innerHTML = `<p>아이폰15프로맥스 512 블루티타늄 자급제</p>
            <p>1,690,000원</p>
            <p><span>갈현제1동</span><span>|</span><span>18분 전</span> </p>`
            
            //상품있는 페이지로 이동
            div.onclick = function(){
                console.log(event.target);
            }
            var loveDel = document.createElement("i");
            loveDel.classList.add("fa-solid");
            loveDel.classList.add("fa-heart");
            loveDel.classList.add("fa-2x");
            
            //찜삭제
            loveDel.onclick = function(){
                console.log(event.target);
            }

            li.appendChild(div);
            li.appendChild(loveDel);
            ul.appendChild(li);
        }
        
        loveContent.appendChild(ul);

        loveWrap.appendChild(loveTop);
        loveWrap.appendChild(loveContent);
                
        
        //찜목록 하단 목록생성
    }
}

chatBtn.onclick = () => {
    if (chatWrap.style.display == "block") {
        chatWrap.style.display = "none"
        chatBtn.style.backgroundColor = "";
        chatTop.innerHTML = "";
        chatBot.innerHTML = "";

    } else {
        chatWrap.style.display = "block"
        chatBtn.style.backgroundColor = "blue";
        chatWrap.style.zIndex = ++zIdxBtn;
        //채팅 대기방 상단 생성
        chatTop.innerHTML = '<div class="chatting-wait"><h1 class="chatting-title">채팅방</h1><i class="fa-solid fa-x fa-2x chatting-close"></i></div > '




        //채팅 대기방 몸체 생성
        var chatBotWait = document.createElement("div");
        chatBotWait.classList.add("chatting-bot-wait");

        var chatContent = document.createElement("ul");
        chatContent.classList.add("chatting-content");

        //대기방 리스트
        for (var i = 0; i < 2; i++) {
            var li = document.createElement("li");
            li.classList.add("chatting-user-list");
            li.innerHTML = '<img src="./img/profile.png" alt="유저이미지"> <div class="user-detail"><div><span class="user-name">닉네임123</span><span>9월 16일</span></div><div><span>마지막 메시지</span></div></div>';

            //클릭시 1대1채팅방 생성
            //(x버튼 누를시 대기방생성도 나중에 고려)
            li.onclick = () => {
                chatTop.innerHTML = "";
                chatBot.innerHTML = "";


                //1대1 채팅창 상단
                var chatInside = document.createElement("div")
                chatInside.classList.add("chatting-inside");

                var h1 = document.createElement("h1");
                h1.classList.add("chatting-title");
                h1.innerText = "닉네임123";

                var closeBtn = document.createElement("i");
                closeBtn.classList.add("chatting-close");
                closeBtn.onclick = () => {
                    //x버튼 누를시 대기방생성
                }
                closeBtn.innerHTML = '<i class="fa-solid fa-x fa-2x"></i>'

                chatInside.appendChild(h1);
                chatInside.appendChild(closeBtn);
                chatTop.appendChild(chatInside);

                //1대1 채팅창 몸체
                var chatInsideBot = document.createElement("div");
                chatInsideBot.classList.add("chatting-bot-inside");

                chatInsideBot.innerHTML = `<div class="chat-title">
                    <img src="./img/profile.png" alt="상품이미지">
                    <div>
                        <p>${"280,000"}원</p>
                        <p>${"피파4 계정판매"}</p>
                    </div>
                </div>

                <div class="chat-content">
                    <div class="chat-content-container">
                        <ul>
                            채팅창 내용
                            <li>
                                <div class="chat-content-box-you">
                                    <div class="chat-content-letter">
                                        <p>안녕하세요@@@@@@@</p>
                                    </div>
                                    <span>오전 2:13</span>
                                </div>
                            </li>
                            <li>
                                <div class="chat-content-box-my">
                                
                                    <div class="chat-content-letter">
                                        <p>안녕하세요@@@@@@@</p>
                                    </div>
                                    <span>오전 2:13</span>
                                </div>

                            </li>
                        </ul>

                    </div>
                </div>

                <div class="chat-input">
                    <form action="#">
                        <textarea name="" id="" placeholder="메시지를 입력해주세요"></textarea>
                    </form>
                </div>`;
                chatBot.appendChild(chatInsideBot);


            }
            chatContent.appendChild(li);
        }

        chatBotWait.appendChild(chatContent);
        chatBot.appendChild(chatBotWait);


    }






}


